from django.shortcuts import render
from django.template import loader
from FlightIndex import models
# Create your views here.

def flights_search(request):
    if request.method=="POST":
        search_dep_day=request.POST.get("dep_day")
        search_dep_city=request.POST.get("dep_city")
        search_arr_city=request.POST.get("arr_city")
        search_isOneWay=request.POST.get("isOneWay")
        models.Airport.objects.create
    return render(request,"flights_view.html",{})

