from django.urls import path
from FlightIndex import views

urlpatterns = [
    path('search/',views.flights_search),# /flights/search/
]